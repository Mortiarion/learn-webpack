export const mult = (a, b) => a * b;
export const sum = async(a, b) => a + b;